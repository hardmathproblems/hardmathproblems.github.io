# Minecraft Indev WebGL

This project aims to be a 1:1 replica of Minecraft Indev 20100223 made using TeaVM and WebGL. This project can be played on almost any device and can be played in the web browser on low-end devices like Chromebooks.

# Project Takedown
This project is just for fun, If this project has to be taken down for any legal reasons please email me at PeytonPlayz585@gmail.com

# Playing in the Web Browser
To play in the web browser please [click here](https://peytonplayz595.github.io/Minecraft-Indev-WebGL/js/). If for some reason it doesn't work please open an issue [here](https://github.com/PeytonPlayz595/Minecraft-Indev-WebGL/issues).

Here are a few reasons that it might not work:
- Your browser doesn't support [HTML5](https://developer.mozilla.org/en-US/docs/Glossary/HTML5), at this point there is no valid excuses...
- Your browser doesn't support [WebGL 2.0](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API)
- Your browser doesn't support [Pointer Lock API](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_Lock_API)
- Your browser doesn't support [IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API)

Try using the latest versions of Chrome, Edge, Opera, or Safari to see if it will work, if it doesn't it might be a driver glitch so just open an issue.

# Pros and Cons
Pros:
- No download, it's playable in your Web Browser for free
- Get's decant FPS on low-end devices like Chromebooks

Cons:
- It's technically a pirated version of the game
- There will be unexpected bugs and glitches
- Probably will be removed due to a DMCA

# Screenshots
