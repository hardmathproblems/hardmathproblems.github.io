#!/bin/sh
java -jar CompilePackage.jar "../resources" "../js/resources.mc"