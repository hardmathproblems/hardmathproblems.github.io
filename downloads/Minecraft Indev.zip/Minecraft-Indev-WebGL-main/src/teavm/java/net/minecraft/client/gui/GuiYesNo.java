package net.minecraft.client.gui;

public class GuiYesNo extends GuiScreen {

}
