package net.minecraft.client;

public final class MinecraftError extends Error {
}
