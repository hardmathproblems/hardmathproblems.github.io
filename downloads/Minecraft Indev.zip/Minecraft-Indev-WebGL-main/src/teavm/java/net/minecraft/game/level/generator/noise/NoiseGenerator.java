package net.minecraft.game.level.generator.noise;

public abstract class NoiseGenerator {
	public abstract double generateNoise(double var1, double var3);
}
