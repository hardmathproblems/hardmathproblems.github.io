package net.PeytonPlayz585.teavm;

import org.teavm.jso.JSObject;

public interface WebGLVertexArray extends JSObject {
}