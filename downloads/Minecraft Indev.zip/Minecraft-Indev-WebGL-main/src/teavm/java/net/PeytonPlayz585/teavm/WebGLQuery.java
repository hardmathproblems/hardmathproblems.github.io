package net.PeytonPlayz585.teavm;

import org.teavm.jso.JSObject;

public interface WebGLQuery extends JSObject {
}